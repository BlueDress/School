﻿define("epi-languagemanager/component/command/CompareWithMasterLanguage", [
// Dojo base
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/_base/Deferred",
    "dojo/topic",
    "dojo/promise/all",
    "dojo/when",

// Epi Framework
    "epi/dependency",
    "epi/Url",
    "epi-cms/core/ContentReference",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/ApplicationSettings",

// Language mangager
    "epi-languagemanager/component/command/CommandBase",
    "epi-languagemanager/component/CompareEditing",

// Resource
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// Dojo base
    declare,
    lang,
    Deferred,
    topic,
    all,
    when,

// Epi Framework
    dependency,
    Url,
    ContentReference,
// Epi CMS
    ContentActionSupport,
    ApplicationSettings,

// Language manager
    CommandBase,
    CompareEditing,

// Resource
    res
) {

    return declare([CommandBase], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: "Compare with {language} (Master)",

        iconClass: 'epi-iconCompare',

        constructor: function (params) {
            this.inherited(arguments);

            if (params && params.model) {
                this.set("label", lang.replace(res.comparewithmasterlanguage, { name: params.model.masterLanguage }));
            }

            this.profile = dependency.resolve("epi.shell.Profile");
            this.set("isAvailable", true);
            this.set("canExecute", true);
        },

        _onModelChange: function () {
            // summary:
            //      Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            var item = this.model.currentItemData;

            if (!item) {
                this.set("canExecute", false);
                return;
            }

            // Do nothing (command disabled) if the content is Wastebasket or Root or has been deleted or is an unsupported type
            var disabled = this.isWastebasket(this.model.contentData) || this.isRoot(this.model.contentData)
                    || this.model.contentData.isDeleted || !this.isSupportedType(this.model.contentData);

            this.set("label", lang.replace(res.comparewithmasterlanguage, { name: this.model.masterLanguage }));

            this.set("isAvailable", !this.category || item.isCreated && item.canEdit && !item.isMaster && item.isActive);
            this.set("canExecute", item.canEdit && item.isCreated && !item.isMaster && item.isActive && !disabled);
        },

        execute: function (/*Mouse event*/evt, /*Boolean?*/isForced) {
            if (!this.model.currentItemData || !this.model.currentItemData.languageID) {
                return;
            }

            // currentItemData.canEdit = false means that the current user has not Edit access right on the language,
            // and he cannot access compare editing
            if (!this.model.currentItemData.canEdit) {
                // set actionExecuted to remove standby widget
                this.model.set("actionExecuted", {});
                return;
            }

            // Make it fullscreen, unpin left and right panel
            topic.publish("/epi/layout/pinnable/navigation/toggle", false);
            topic.publish("/epi/layout/pinnable/tools/toggle", false);

            // Save current pinnable state for restoring later
            var self = this;
            all({
                toolsSettings: self.profile.get("tools"),
                navigationSettings: self.profile.get("navigation")
            }).then(function (results) {
                var toolsPinned = results && results.toolsSettings && results.toolsSettings.pinned,
                    navigationPinned = results && results.navigationSettings && results.navigationSettings.pinned;

                self.profile.set("addons-language-manager-settings", {
                    toolsPinned: toolsPinned,
                    navigationPinned: navigationPinned
                });
            });

            // Switch to compare view
            var currentContentLanguage = new Url(window.location.href).query.language,
                currentItemLanguage = this.model.currentItemData.languageID,
                shouldReload = currentContentLanguage != currentItemLanguage;

            // This is for getting the content id without WorkId (e.g. 6 instead of 6_1234).
            // The resolver on server will automatically get the latest version
            var contentReference = new ContentReference(this.model.context.id);
            var contentReferenceWithoutVersion = contentReference.createVersionUnspecificReference();

            if (shouldReload) {
                // If the comparing language is different from the current content language,
                // then we need to switch the content language to the comparing language before making comparison
                
                var currentUrl = new Url(window.location.href),
                    currentUrlPath = currentUrl.scheme + "://" + currentUrl.authority + currentUrl.path,
                    reloadUrl = currentUrlPath + "?language=" + currentItemLanguage + "#context=epi.cms.languagemanager.compareediting:///" + contentReferenceWithoutVersion;

                when(self.profile.setContentLanguage(currentItemLanguage, currentUrl.authority)).then(function () {
                    window.location.replace(reloadUrl);
                });
            }
            else {
                topic.publish("/epi/shell/context/request", { uri: "epi.cms.languagemanager.compareediting:///" + contentReferenceWithoutVersion }, { languageManagerAction: "compare", trigger: "internal" });
            }
        }
    });
});