define("epi-languagemanager/contentediting/editors/CreateLanguageBranch", [
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
// epi
    "epi/Url",
    "epi/dependency",
    "epi-cms/contentediting/CreateContent",
    "epi-cms/contentediting/viewmodel/CreateLanguageBranchViewModel"
],

function (
// dojo
    declare,
    lang,
    when,
// epi
    Url,
    dependency,
    CreateContent,
    CreateLanguageBranchViewModel
) {

    return declare([CreateContent], {
        modelType: CreateLanguageBranchViewModel,        

        postCreate: function () {
            // summary:
            //		Post widget creation handler.
            // tags:
            //		protected

            this.inherited(arguments);

            this.profile = this.profile || dependency.resolve("epi.shell.Profile");
        },

        _setCreateMode: function () {
            // summary:
            //      Set create new content state for current mode
            // tags:
            //      protected extension

            lang.mixin(this._contextService.currentContext, {
                currentMode: "translate"
            });
        },

        _changeContext: function (contentLink) {
            // summary:
            //    Redirect the newly created content to editmode with language context.
            //
            // contentLink:
            //    The content link.
            
            var self = this;
            var host = window.location.host;

            // click on the language branch under a site (root node)
            when(this.profile.setContentLanguage(this.model.languageBranch, host), function () {
                var currentItemLanguage = self.model.languageBranch;
                var uri = "#context=epi.cms.contentdata:///" + contentLink,
                    currentUrl = new Url(window.location.href),
                    currentUrlPath = currentUrl.scheme + "://" + currentUrl.authority + currentUrl.path,
                    urlToNavigate = currentUrlPath + "?language=" + currentItemLanguage + uri;

                window.location.replace(urlToNavigate);
            });
        },
    });
});