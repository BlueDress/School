﻿define("epi-languagemanager/component/command/UploadTranslationPackages", [
// dojo
    'dojo/_base/declare',
    'dojo/_base/lang',
// epi

// language manager
    'epi-languagemanager/component/command/CommandBase',
// resources
    "epi/i18n!epi/cms/nls/languagemanager.gadget"
],
function (
// dojo
    declare,
    lang,
// epi

// language manager
    CommandBase,
// resources
    res
) {

    return declare([CommandBase], {

        // label: [public] String
        //      The action text of the command to be used in visual elements.
        label: res.uploadtranslationpackages,

        category: 'context',

        // fileCollection: [public] Array
        //      An array of files to upload.
        //      When null, only show upload form to select files for uploading; otherwise, upload files in list.
        fileCollection: null,

        // iconClass: [public] String
        //      The icon class of the command to be used in visual elements.
        iconClass: "epi-iconUpload",

        constructor: function () {
            // summary:
            //      Sets initialize values for this command.
            // tags:
            //      public, extensions

            this.inherited(arguments);

            this.set('isAvailable', true);
            this.set('canExecute', true);
        },

        _execute: function () {
            // summary:
            //      Executes this command. Call upload method from model.
            // tags:
            //      protected, extensions

            if (!this.model || typeof this.model.uploadTranslationPackages !== 'function') {
                return;
            }

            this.model.uploadTranslationPackages(this.fileCollection);

            // Clear fileCollection after uploading, to avoid of displaying last uploaded item on upload dialog.
            this.fileCollection = null;
        }
    });
});