﻿

namespace Define_a_class_Person
{
    public class Person
    {
        public string name;
        public int age;
    }
}
