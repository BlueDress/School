﻿

using System.Collections.Generic;


    public class Group
    {
        public Town Town { get; set; }
        public List<Student> Students { get; set; }
    }

