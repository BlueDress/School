﻿
using System.Collections.Generic;


    public class Town
    {
        public string Name { get; set; }
        public int Seats { get; set; }
        public List<Student> Students { get; set; }
        public int Groups { get; set; }
    }
