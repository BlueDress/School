﻿


    public class Client
    {
        public string Name { get; set; }
        public string Order { get; set; }
        public int Quantity { get; set; }
        public decimal Bill { get; set; }
    }

