<?php

/* base.html.twig */
class __TwigTemplate_1da1fc0c7d127f7a3f4da51708e47abe7f949e951f2088d42cbe9c227d84e799 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_663196e5f2b177d915bb5e3103eb389fc542f154888a130ea0e42742a3ec9453 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_663196e5f2b177d915bb5e3103eb389fc542f154888a130ea0e42742a3ec9453->enter($__internal_663196e5f2b177d915bb5e3103eb389fc542f154888a130ea0e42742a3ec9453_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>


";
        // line 51
        $this->displayBlock('javascripts', $context, $blocks);
        // line 57
        echo "
</body>
</html>
";
        
        $__internal_663196e5f2b177d915bb5e3103eb389fc542f154888a130ea0e42742a3ec9453->leave($__internal_663196e5f2b177d915bb5e3103eb389fc542f154888a130ea0e42742a3ec9453_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_46586137f185b5e05cf1c62ade3a1705b7021cb3ee33ceb974d0d0689d9d89d8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_46586137f185b5e05cf1c62ade3a1705b7021cb3ee33ceb974d0d0689d9d89d8->enter($__internal_46586137f185b5e05cf1c62ade3a1705b7021cb3ee33ceb974d0d0689d9d89d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_46586137f185b5e05cf1c62ade3a1705b7021cb3ee33ceb974d0d0689d9d89d8->leave($__internal_46586137f185b5e05cf1c62ade3a1705b7021cb3ee33ceb974d0d0689d9d89d8_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_6a8c84a4ac344fb7774e2e9dceabe9a414b058f5cbb2f39bf5dc5ae7fbd38457 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6a8c84a4ac344fb7774e2e9dceabe9a414b058f5cbb2f39bf5dc5ae7fbd38457->enter($__internal_6a8c84a4ac344fb7774e2e9dceabe9a414b058f5cbb2f39bf5dc5ae7fbd38457_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_6a8c84a4ac344fb7774e2e9dceabe9a414b058f5cbb2f39bf5dc5ae7fbd38457->leave($__internal_6a8c84a4ac344fb7774e2e9dceabe9a414b058f5cbb2f39bf5dc5ae7fbd38457_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_5a69dae3f3d53d1d11121388d02d4fb456dfa09c141aab92bfcbe4bec8279277 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5a69dae3f3d53d1d11121388d02d4fb456dfa09c141aab92bfcbe4bec8279277->enter($__internal_5a69dae3f3d53d1d11121388d02d4fb456dfa09c141aab92bfcbe4bec8279277_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_5a69dae3f3d53d1d11121388d02d4fb456dfa09c141aab92bfcbe4bec8279277->leave($__internal_5a69dae3f3d53d1d11121388d02d4fb456dfa09c141aab92bfcbe4bec8279277_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_122cc8c390b1d267a1f943376cd9a1ac5c134788d2a251d259d93eeda228757f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_122cc8c390b1d267a1f943376cd9a1ac5c134788d2a251d259d93eeda228757f->enter($__internal_122cc8c390b1d267a1f943376cd9a1ac5c134788d2a251d259d93eeda228757f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_122cc8c390b1d267a1f943376cd9a1ac5c134788d2a251d259d93eeda228757f->leave($__internal_122cc8c390b1d267a1f943376cd9a1ac5c134788d2a251d259d93eeda228757f_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_c0451fd4fa196a046a97477694e96d27b71031cc58f4bf719b00e10090c4bcc9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c0451fd4fa196a046a97477694e96d27b71031cc58f4bf719b00e10090c4bcc9->enter($__internal_c0451fd4fa196a046a97477694e96d27b71031cc58f4bf719b00e10090c4bcc9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_c0451fd4fa196a046a97477694e96d27b71031cc58f4bf719b00e10090c4bcc9->leave($__internal_c0451fd4fa196a046a97477694e96d27b71031cc58f4bf719b00e10090c4bcc9_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_328c5e8410007eac245178a4ab3abed178a70385ce2642e2a48da626ed9be1a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_328c5e8410007eac245178a4ab3abed178a70385ce2642e2a48da626ed9be1a2->enter($__internal_328c5e8410007eac245178a4ab3abed178a70385ce2642e2a48da626ed9be1a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_328c5e8410007eac245178a4ab3abed178a70385ce2642e2a48da626ed9be1a2->leave($__internal_328c5e8410007eac245178a4ab3abed178a70385ce2642e2a48da626ed9be1a2_prof);

    }

    // line 51
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_c4829ebbb2e474888a2f15e544189af644e8e6939815de1c92b719c98fa5724c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c4829ebbb2e474888a2f15e544189af644e8e6939815de1c92b719c98fa5724c->enter($__internal_c4829ebbb2e474888a2f15e544189af644e8e6939815de1c92b719c98fa5724c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 52
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 53
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 54
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_c4829ebbb2e474888a2f15e544189af644e8e6939815de1c92b719c98fa5724c->leave($__internal_c4829ebbb2e474888a2f15e544189af644e8e6939815de1c92b719c98fa5724c_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  205 => 55,  201 => 54,  197 => 53,  192 => 52,  186 => 51,  175 => 44,  166 => 45,  164 => 44,  160 => 42,  154 => 41,  134 => 26,  128 => 22,  122 => 21,  111 => 19,  102 => 14,  97 => 13,  91 => 12,  79 => 11,  69 => 57,  67 => 51,  62 => 48,  60 => 41,  56 => 39,  54 => 21,  49 => 19,  42 => 16,  40 => 12,  36 => 11,  29 => 6,);
    }

    public function getSource()
    {
        return "{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>


{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
";
    }
}
