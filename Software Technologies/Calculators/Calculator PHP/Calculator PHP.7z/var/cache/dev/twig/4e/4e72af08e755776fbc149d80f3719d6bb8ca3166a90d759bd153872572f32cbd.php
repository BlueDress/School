<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_ff2e459b395df004e547a2c4b7704c5bca0271fdbf4941fccfa9e6f7baf444d6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d1852fb75a61407d8ddd97f3a3bb5ef0430fb6c719d5ce420b3fb9e9bb484398 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d1852fb75a61407d8ddd97f3a3bb5ef0430fb6c719d5ce420b3fb9e9bb484398->enter($__internal_d1852fb75a61407d8ddd97f3a3bb5ef0430fb6c719d5ce420b3fb9e9bb484398_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d1852fb75a61407d8ddd97f3a3bb5ef0430fb6c719d5ce420b3fb9e9bb484398->leave($__internal_d1852fb75a61407d8ddd97f3a3bb5ef0430fb6c719d5ce420b3fb9e9bb484398_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_bc4b87292313a5d8ae2a107b96db4f8b1963dfabaa15069ae79a78fe7a6bb8f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc4b87292313a5d8ae2a107b96db4f8b1963dfabaa15069ae79a78fe7a6bb8f1->enter($__internal_bc4b87292313a5d8ae2a107b96db4f8b1963dfabaa15069ae79a78fe7a6bb8f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_bc4b87292313a5d8ae2a107b96db4f8b1963dfabaa15069ae79a78fe7a6bb8f1->leave($__internal_bc4b87292313a5d8ae2a107b96db4f8b1963dfabaa15069ae79a78fe7a6bb8f1_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_1522f5ffb4db2374bf1ac018fff61c139cdd1429f093a3accb7898acaaa54b46 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1522f5ffb4db2374bf1ac018fff61c139cdd1429f093a3accb7898acaaa54b46->enter($__internal_1522f5ffb4db2374bf1ac018fff61c139cdd1429f093a3accb7898acaaa54b46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_1522f5ffb4db2374bf1ac018fff61c139cdd1429f093a3accb7898acaaa54b46->leave($__internal_1522f5ffb4db2374bf1ac018fff61c139cdd1429f093a3accb7898acaaa54b46_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_f688019f79b3b7b7deeb1d937a61a6fac329f2813d1b3f53901d4e3f91c78e45 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f688019f79b3b7b7deeb1d937a61a6fac329f2813d1b3f53901d4e3f91c78e45->enter($__internal_f688019f79b3b7b7deeb1d937a61a6fac329f2813d1b3f53901d4e3f91c78e45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_f688019f79b3b7b7deeb1d937a61a6fac329f2813d1b3f53901d4e3f91c78e45->leave($__internal_f688019f79b3b7b7deeb1d937a61a6fac329f2813d1b3f53901d4e3f91c78e45_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
