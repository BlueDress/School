<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_6c1fcc0007234701a2edc47ef770fc4b2fd663f2d8254000d89996cda384aeaa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_557cd80f3b4ce081acffe1f6d6d1bb294fddada526b3983fdd3f3af7b7b6762a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_557cd80f3b4ce081acffe1f6d6d1bb294fddada526b3983fdd3f3af7b7b6762a->enter($__internal_557cd80f3b4ce081acffe1f6d6d1bb294fddada526b3983fdd3f3af7b7b6762a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_557cd80f3b4ce081acffe1f6d6d1bb294fddada526b3983fdd3f3af7b7b6762a->leave($__internal_557cd80f3b4ce081acffe1f6d6d1bb294fddada526b3983fdd3f3af7b7b6762a_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_d0077bad26346576dfc372173787f488a16e56ed2e36d26c7f1592516c989f26 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d0077bad26346576dfc372173787f488a16e56ed2e36d26c7f1592516c989f26->enter($__internal_d0077bad26346576dfc372173787f488a16e56ed2e36d26c7f1592516c989f26_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_d0077bad26346576dfc372173787f488a16e56ed2e36d26c7f1592516c989f26->leave($__internal_d0077bad26346576dfc372173787f488a16e56ed2e36d26c7f1592516c989f26_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_973487adf01f4f77e73deaa921d80849bfbebe77e6d9846c463bae79d3031a4a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_973487adf01f4f77e73deaa921d80849bfbebe77e6d9846c463bae79d3031a4a->enter($__internal_973487adf01f4f77e73deaa921d80849bfbebe77e6d9846c463bae79d3031a4a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_973487adf01f4f77e73deaa921d80849bfbebe77e6d9846c463bae79d3031a4a->leave($__internal_973487adf01f4f77e73deaa921d80849bfbebe77e6d9846c463bae79d3031a4a_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_e24bd28388408648b9fc38aa607dddac82069b294bf54516630e86e914151d24 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e24bd28388408648b9fc38aa607dddac82069b294bf54516630e86e914151d24->enter($__internal_e24bd28388408648b9fc38aa607dddac82069b294bf54516630e86e914151d24_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_e24bd28388408648b9fc38aa607dddac82069b294bf54516630e86e914151d24->leave($__internal_e24bd28388408648b9fc38aa607dddac82069b294bf54516630e86e914151d24_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}
