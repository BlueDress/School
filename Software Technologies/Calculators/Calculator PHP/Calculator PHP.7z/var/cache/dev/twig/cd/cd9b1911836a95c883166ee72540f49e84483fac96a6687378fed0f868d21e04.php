<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_0617025d13c1217f309d8f16c3a20c4a8557e32e7999b048c544a16408e2c48c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8f5eb4cda1e86f4985b9ab129fcb26b3031260451bd882e310048a045dc56ab7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8f5eb4cda1e86f4985b9ab129fcb26b3031260451bd882e310048a045dc56ab7->enter($__internal_8f5eb4cda1e86f4985b9ab129fcb26b3031260451bd882e310048a045dc56ab7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_8f5eb4cda1e86f4985b9ab129fcb26b3031260451bd882e310048a045dc56ab7->leave($__internal_8f5eb4cda1e86f4985b9ab129fcb26b3031260451bd882e310048a045dc56ab7_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_500fc2fac9d43c438882f1768c2e16fae4d7eceb074de1ac8d98d3eca7db8912 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_500fc2fac9d43c438882f1768c2e16fae4d7eceb074de1ac8d98d3eca7db8912->enter($__internal_500fc2fac9d43c438882f1768c2e16fae4d7eceb074de1ac8d98d3eca7db8912_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_500fc2fac9d43c438882f1768c2e16fae4d7eceb074de1ac8d98d3eca7db8912->leave($__internal_500fc2fac9d43c438882f1768c2e16fae4d7eceb074de1ac8d98d3eca7db8912_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_0862b1a0b1a5975dc53b5bd1ccb08c793ee9d5a7f322d2886d8997d22e326744 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_0862b1a0b1a5975dc53b5bd1ccb08c793ee9d5a7f322d2886d8997d22e326744->enter($__internal_0862b1a0b1a5975dc53b5bd1ccb08c793ee9d5a7f322d2886d8997d22e326744_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_0862b1a0b1a5975dc53b5bd1ccb08c793ee9d5a7f322d2886d8997d22e326744->leave($__internal_0862b1a0b1a5975dc53b5bd1ccb08c793ee9d5a7f322d2886d8997d22e326744_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_4336c74037767ee94b4508d7afa510a5beb71bbb2a4798558af09b003f547431 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4336c74037767ee94b4508d7afa510a5beb71bbb2a4798558af09b003f547431->enter($__internal_4336c74037767ee94b4508d7afa510a5beb71bbb2a4798558af09b003f547431_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_4336c74037767ee94b4508d7afa510a5beb71bbb2a4798558af09b003f547431->leave($__internal_4336c74037767ee94b4508d7afa510a5beb71bbb2a4798558af09b003f547431_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 33,  114 => 32,  108 => 28,  106 => 27,  102 => 25,  96 => 24,  88 => 21,  82 => 17,  80 => 16,  75 => 14,  70 => 13,  64 => 12,  54 => 9,  48 => 6,  45 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
";
    }
}
