<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_352b4ab8dceddb4f13314cb711a4a3c9e53d331c18aacf14544399d530c24b21 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a0151b99e941c2849e47410118c3d6e4000a86497bd6157546ae55f2235e5b98 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a0151b99e941c2849e47410118c3d6e4000a86497bd6157546ae55f2235e5b98->enter($__internal_a0151b99e941c2849e47410118c3d6e4000a86497bd6157546ae55f2235e5b98_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a0151b99e941c2849e47410118c3d6e4000a86497bd6157546ae55f2235e5b98->leave($__internal_a0151b99e941c2849e47410118c3d6e4000a86497bd6157546ae55f2235e5b98_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_365ba0f830afd36c385ead2bb3a5b0f442f8af8f6aa97fba417030077a2e7dd7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_365ba0f830afd36c385ead2bb3a5b0f442f8af8f6aa97fba417030077a2e7dd7->enter($__internal_365ba0f830afd36c385ead2bb3a5b0f442f8af8f6aa97fba417030077a2e7dd7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_365ba0f830afd36c385ead2bb3a5b0f442f8af8f6aa97fba417030077a2e7dd7->leave($__internal_365ba0f830afd36c385ead2bb3a5b0f442f8af8f6aa97fba417030077a2e7dd7_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_8fe415f6c9d2849f041c600ee51e0eba49e9082af32ee8d40e3700416a9a83e7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8fe415f6c9d2849f041c600ee51e0eba49e9082af32ee8d40e3700416a9a83e7->enter($__internal_8fe415f6c9d2849f041c600ee51e0eba49e9082af32ee8d40e3700416a9a83e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_8fe415f6c9d2849f041c600ee51e0eba49e9082af32ee8d40e3700416a9a83e7->leave($__internal_8fe415f6c9d2849f041c600ee51e0eba49e9082af32ee8d40e3700416a9a83e7_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_318e263a0f0a50c545c7ad1a9ea3a1098e8e11f96414c8f14b951477c530a678 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_318e263a0f0a50c545c7ad1a9ea3a1098e8e11f96414c8f14b951477c530a678->enter($__internal_318e263a0f0a50c545c7ad1a9ea3a1098e8e11f96414c8f14b951477c530a678_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_318e263a0f0a50c545c7ad1a9ea3a1098e8e11f96414c8f14b951477c530a678->leave($__internal_318e263a0f0a50c545c7ad1a9ea3a1098e8e11f96414c8f14b951477c530a678_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
";
    }
}
