<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_562e7faab429c22cd2c5d6e015fc0b94f0e19ff34fa87d8483d484c816d9e5f6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e06b9c058ec2953732610f29624cb12752b319ad7431ec1646b62ec752b31c02 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e06b9c058ec2953732610f29624cb12752b319ad7431ec1646b62ec752b31c02->enter($__internal_e06b9c058ec2953732610f29624cb12752b319ad7431ec1646b62ec752b31c02_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e06b9c058ec2953732610f29624cb12752b319ad7431ec1646b62ec752b31c02->leave($__internal_e06b9c058ec2953732610f29624cb12752b319ad7431ec1646b62ec752b31c02_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_2651178b41f65da7fd7d3b639a49a280b8014a894c63567494ca45ab9c4c9af4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2651178b41f65da7fd7d3b639a49a280b8014a894c63567494ca45ab9c4c9af4->enter($__internal_2651178b41f65da7fd7d3b639a49a280b8014a894c63567494ca45ab9c4c9af4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_2651178b41f65da7fd7d3b639a49a280b8014a894c63567494ca45ab9c4c9af4->leave($__internal_2651178b41f65da7fd7d3b639a49a280b8014a894c63567494ca45ab9c4c9af4_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_2407ff1f9869dccd942d6c2fbd91c7d05d796fcfffcabb1ae286fb688f48b985 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2407ff1f9869dccd942d6c2fbd91c7d05d796fcfffcabb1ae286fb688f48b985->enter($__internal_2407ff1f9869dccd942d6c2fbd91c7d05d796fcfffcabb1ae286fb688f48b985_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_2407ff1f9869dccd942d6c2fbd91c7d05d796fcfffcabb1ae286fb688f48b985->leave($__internal_2407ff1f9869dccd942d6c2fbd91c7d05d796fcfffcabb1ae286fb688f48b985_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_cf064affd09269f5cb9b023d917975978eaea01a48c828f7d3b85a4161dbe4be = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_cf064affd09269f5cb9b023d917975978eaea01a48c828f7d3b85a4161dbe4be->enter($__internal_cf064affd09269f5cb9b023d917975978eaea01a48c828f7d3b85a4161dbe4be_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_cf064affd09269f5cb9b023d917975978eaea01a48c828f7d3b85a4161dbe4be->leave($__internal_cf064affd09269f5cb9b023d917975978eaea01a48c828f7d3b85a4161dbe4be_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
";
    }
}
